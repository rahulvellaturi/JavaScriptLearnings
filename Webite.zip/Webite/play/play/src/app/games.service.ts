import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GamesService {

  game_amt;
  constructor() { }

  getAmount(amt)
  {
        this.game_amt = amt;
  }

}
