import { Component, OnInit } from '@angular/core';
import { GamesService } from '../games.service';
import { ActivatedRoute } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {

  card_amount;
  cardid;
  game_details;
  details;
  pname;
  pprice;
  pid;
  totalamt;
  cards_amount;
  constructor(private cd:GamesService,private rout:ActivatedRoute,private http:HttpClient) {
    
    this.rout.params.subscribe((parameters)=>{
        this.cardid = parameters['amt'];
    })
      this.card_amount = this.cd.game_amt;
      this.http.get("http://localhost:3000/game/" + this.cardid)

      .subscribe((data)=>{
          this.game_details = data;
          this.pprice= this.game_details.price;
          this.pname = this.game_details.name;
          this.cards_amount = this.game_details.cardBalance;
      })
      this.totalamt = this.card_amount - this.pprice;

  }
  ngOnInit() {
  }

}
