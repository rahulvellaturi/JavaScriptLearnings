import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GameCityComponent } from './game-city/game-city.component';
import { PlayComponent } from './play/play.component';

const routes: Routes = 
[
  {path:'game',component:GameCityComponent},
  {path:'play/:amtt',component:PlayComponent},
  {path:'',component:GameCityComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
