import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-game-city',
  templateUrl: './game-city.component.html',
  styleUrls: ['./game-city.component.css']
})
export class GameCityComponent implements OnInit {

  name;
  address;
  amount;
  cardBalance;
  myForm = new FormGroup({
    name:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]{1,}')]),
    address:new FormControl('',[Validators.required]),
    amount:new FormControl('',[Validators.required])
  })
  constructor(private http:HttpClient) {

   }

  play_messages = 
  {
    "name":
    [
      {type:'required',message:'Name is required'},
      {type:'pattern',message:'Only Characters allowed & No sapces allowed'}
    ],
    "address":
    [
      {type:'required',message:'Address is required'}
    ],
    "amount":
    [
      {type:'required',message:'Amount is required'}
    ]
  }

  buyCard()
  {
      this.cardBalance = this.amount-100;
      var json = {id:this.amount, price:this.cardBalance,name:this.name}
      var head = new HttpHeaders({'Content-Type':'application/json'})
      this.http.post("http://localhost:3000/amount/",json,({headers:head}))

      .subscribe(()=>{

        alert("added")
      })

  }

  empid = prompt("Enter your Employee ID");
  ngOnInit() {
  }

}
