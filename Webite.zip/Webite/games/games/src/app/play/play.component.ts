import { Component, OnInit } from '@angular/core';
import { GamecityService } from '../gamecity.service';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {

  game_details;
  cardBalance;
  total;
  amtid;
  constructor(private cd:GamecityService,private http:HttpClient,private rout:ActivatedRoute) {

    this.game_details = this.cd.getDetails()
    .subscribe((data)=>{

      this.game_details = data;
    })

    this.rout.params.subscribe((parameters)=>{

      this.amtid = parameters['amtt'];
    })

    this.http.get("http://localhost:3000/amount/" + this.amtid)

    .subscribe((data)=>{

        this.total= data;

        this.cardBalance = this.total.price;
    })
   }
  ngOnInit() {
  }

}
