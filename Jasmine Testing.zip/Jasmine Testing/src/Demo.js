class calculator
{
    add(a,b)
    {
        return a+b;
    }
}

class TestString
{
    countVowel(st)
    {
        
        var s1 = ' ';
        for (var i=0; i<st.length; i++)
        {
            var s = st.charAt(i);
            if (s == 'a' || s == 'e' || s == 'i' || s == 'o' || s == 'u')
            {
                if (s1.includes(s)){
                continue;
            }
            s1=s1+s;
            }
        }
        
        return s1.length;
    }
}