describe("DemoSpec",function(){
    var cal;
   var ts;
    beforeEach(function(){
        cal = new calculator();
        ts = new TestString();
    })
    describe("calculating add,mul,sub,div",function(){
        it("adding two values",function()
        {
            expect(cal.add(3,4)).toEqual(7)
        })
    })
    describe("Testing String",function()
    {
        it("count vowels",function()
        {
            expect(ts.countVowel('capgemini')).toEqual(4);
        })
    })
})