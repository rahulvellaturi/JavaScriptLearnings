import React,{Component} from 'react';
import {Link} from 'react-router-dom'
// import { connect } from 'net';

class Home extends Component {
    render() {
        return (
            <div>
                <Link to = {{pathname: '/add' }} className="btn btn-primary">Add</Link>
                <Link to = {{pathname: '/show'}} className="btn btn-secondary">Show</Link>
                <Link to = {{pathname: '/search'}} className="btn btn-light">Search</Link>
                <Link to = {{pathname: '/showdata'}} className="btn btn-info">Show Searched Data</Link>
            </div>
        )
    }
}

export default Home;