import React from 'react';
// import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Route} from 'react-router-dom'
import Home from './home';
import Show from './show';
import Add from './add';
import Search from './search';
import Showdata from './showdata';

function App() {
  return (
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
    <div>
      <BrowserRouter>
        <Route exact path="/" component={Home}/>
        <Route path="/show" component={Show}/>
        <Route path="/add" component={Add}/>
        <Route path="/search" component={Search}/>
        <Route path="/showdata" component={Showdata}/>
      </BrowserRouter>
    </div>
  );
}

export default App;
