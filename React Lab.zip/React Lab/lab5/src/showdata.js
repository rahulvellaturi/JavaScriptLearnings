import React,{Component} from 'react';
import { connect } from 'react-redux';

class Showdata extends Component {
        render() {
            return(
                <div align="center">
            <h1>Employee Details</h1>
                <table className="table table-striped">
                    <tr align="center">
                        <th>ID</th>
                        <th>Name</th>
                        <th>Salary</th>
                        <th>Department</th>
                        <th></th>
                    </tr>
                    {this.props.employeestate.em.map((e,i)=>(
                        <tr align="center">
                        <td>{e.id}</td>
                        <td>{e.name}</td>
                        <td>{e.salary}</td>
                        <td>{e.department}</td>
                        <td> <button onClick={()=>{
                            this.props.dispatch({type:'deleteSearch',id:e.id})
                              this.props.history.push('/')
                        }}>delete</button></td>
                        </tr>
                    ))}
                </table>
            </div>
            )
        }
}
const mapStateToProps = (state)=>{
    return{
        employeestate: state.employeereducer
    }
}

export default connect (mapStateToProps)(Showdata);
