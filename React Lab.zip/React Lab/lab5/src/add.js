import React,{Component} from 'react';
import { bindActionCreators } from 'C:/Users/learning/AppData/Local/Microsoft/TypeScript/3.4.3/node_modules/redux';
import { connect } from 'react-redux';

class Add extends Component {
    render() {
        return(
            <div>
                id: 
                <input type="text" ref="id"/><br/>
                Name: 
                <input type="text" ref="name"/><br/>
                Salary: 
                <input type="text" ref="salary"/><br/>
                Department: 
                <input type="text" ref="department"/><br/>
                <button onClick={()=>{
                    this.props.dispatch({type: 'add', id:this.refs.id.value, n:this.refs.name.value, s:this.refs.salary.value, d:this.refs.department.value})
                    this.props.history.push('/')
                }}>Add</button>
            </div>
        )
    }
}
const mapDispatchToProps = (dispatch)=>{
    return {
        actions: bindActionCreators(dispatch)
    }

}
export default connect(mapDispatchToProps)(Add);