import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import { combineReducers, createStore } from 'redux';
import { Provider } from 'react-redux';
import 'bootstrap/dist/css/bootstrap.min.css'
// import * as serviceWorker from './serviceWorker';

let initialState = {
    employees: [
        {id:1001, name:"Rahul", salary: 8888, department: "java"},
        {id:1002, name:"Vikash", salary: 8811, department: "Devops"},
        {id:1003, name:"Diva", salary: 7115, department: "BI"}
    ],
    em: []
}

let employeereducer = (state=initialState, action)=> {
    switch(action.type) {
        case 'add':
        let emps = state.employees;
        let employee = {id: action.id, name: action.n, salary: action.s, department: action.d}
        emps.push(employee)
        state ={
            employees: emps
        }
        return state;
        case 'show':
            let emp12 = [];
            let p1 = state.employees;
            p1.map((e1,i)=>{
                if(action.id == e1.id)
                {
                    emp12.push(e1)
                }
            })
        return state;
        case 'search':
            let em=state.employees;
            let es=[];
            em.map((a,i)=>{
                if(a.id == action.id)
                {
                    es.push(a)
                }
            })
            state={
                em: es
            }
        return state;
        case 'showdata':
        return state;
        default:
        return state;
        case 'delete':
        let emp1=state.employees;
        emp1.map((b,i)=>{
            if(b.id==action.id){
            emp1.splice(i,1)
            }
        })
        state={
            employees:emp1
        }
        return state
        case 'deleteSearch':
        let empls = state.employees;
        empls.map((a, i)=>{
            if (a.id == action.i){
                empls.splice(i,1)
            }})
        state ={
            employees: empls
        }
    }
}
let reducer = combineReducers({employeereducer})

const store = createStore(reducer)

ReactDOM.render(<Provider store={store}><App /></Provider>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
// serviceWorker.unregister();


// import React from 'react';
// import ReactDOM from 'react-dom';
// import App from './App';
// import './index.css';
// import { combineReducers, createStore } from 'redux';
// import {Provider} from 'react-redux'

// let initialState={
//   employees:[
//     {id:1001,name:"Rahul",salary:21000, department:"Java"},
//     {id:1002,name:"Vikash",salary:9000, department:"Devops"},
//     {id:1003,name:"Diva",salary:89000, department:"BI"},
//     {id:1004,name:"Ghost",salary:31000, department:"FS"}
//   ],
//   esearch:[]
// }

// let employeesreducer=(state=initialState,action)=>{
//   switch(action.type){
//     case 'add':
//       let emp=state.employees;
//       let p={id:action.id,name:action.n,salary:action.p,department:action.d}
//       emp.push(p)
//       state={ 
//         employees:emp
//       }
//       return state;
//     case 'search':
//       let emps=state.employees;
//       let es=[];
//       emps.map((a,i)=>{
//        if(a.id==action.id)
//        {
//          es.push(a);
//        }
//      })
//      state={
//        esearch:es
//      }
//       return state;
//     case 'delete':
//       let empsds=state.employees;
//       empsds.map((b,i)=>{
//         if(b.id==action.id){
//           empsds.splice(i,1)
//         }
//       })
//       state={
//         employees:empsds
//       }
//       return state
//       case 'deleteSearch':
//       let empsearch=state.esearch;
//       empsearch.map((b,i)=>{
//         if(b.id==action.id){
//           empsearch.splice(i,1)
//         }
//       })
//       state={
//         employees:empsearch
//       }
//       return state
//     default:
//       return state;
//   }
// }

// let reducer= combineReducers({employeesreducer})

// const store=createStore(reducer)

// ReactDOM.render(
//  <Provider store={store}> <App /></Provider>,
//   document.getElementById('root')
// );

