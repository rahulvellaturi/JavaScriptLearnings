import React,{Component} from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

class Search extends Component {
    render() {
        return(
            <div>
                Enter Employee ID to be searched
                <input type="text"ref="id"/>
                <button onClick={()=>{
                    this.props.dispatch({type: 'search', id:this.refs.id.value})
                    this.props.history.push('/showdata')
                }}>Search</button>
                </div>
        )
    }
}
const mapDispatchToProps = (dispatch)=>{
    return{
        actions: bindActionCreators(dispatch)
    }
}
export default connect(mapDispatchToProps)(Search);