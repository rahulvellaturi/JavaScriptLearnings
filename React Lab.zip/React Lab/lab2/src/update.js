import React,{Component} from 'react';
import Axios from 'axios';

class Update extends Component {
    updateEmployee = () => {
        let i = this.refs.id.value;
        let n = this.refs.name.value;
        let s = this.refs.salary.value;
        let d = this.refs.dept.value;
        let em = {id: i,name: n, sal: s, dep: d};
        Axios.put('http://localhost:4001/update/'+n,em)
        .then(()=> {
            this.props.history.push('/')
        })
    }
    render() {
        return (
            <div>
                <table className="table table-striped">
                <tr>
                    <td>ID:</td>
                    <td><input type="text" ref="id" defaultValue={this.props.location.state.employee.empid}/></td>
                </tr>
                    <tr>
                        <td>Name:</td>
                        <td><input type="text" ref="name" defaultValue={this.props.location.state.employee.empname}/></td>
                    </tr>
                    <tr>
                        <td>Salary:</td>
                        <td><input type="text" ref="salary" defaultValue={this.props.location.state.employee.empsal}/></td>
                    </tr>
                    <tr>
                        <td>Department:</td>
                        <td><input type="text" ref="dept" defaultValue={this.props.location.state.employee.empdep}/></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><button onClick={this.updateEmployee} className="btn btn-success">Save</button></td>
                    </tr>
                </table>
            </div>
        )
    }
}
export default Update;