import React,{ Component } from "react";
import Axios from 'axios';

class Search extends Component{
    searchEmp=()=>{
        let i=this.refs.id.value
        Axios.get('http://localhost:4001/search/'+i)
        .then((res)=>{
            this.props.history.push({pathname:"/showsearch",state:{employee:res.data}})
        })
    }
    render () {
        return(
            <div>
                Enter ID to be Searched: <input type="text" ref="id"/><br/>
                <button onClick={this.searchEmp}>Search</button>
            </div>
        )
    }
}
export default Search;