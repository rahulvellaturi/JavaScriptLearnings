import React,{Component} from 'react';
import {Link} from 'react-router-dom'

class Homeemp extends Component {
    render() {
        return(
            <div>
                <Link to ={{pathname:'/add'}} className="btn btn-primary">Add</Link>
                <Link to ={{pathname:'/show'}} className="btn btn-secondary">Show</Link>
                <Link to ={{pathname:'/search'}} className="btn btn-warning">Search</Link>
                <Link to ={{pathname:'/showSearch'}} className="btn btn-disable">Show searched data</Link>
            </div>
        )
    }
}
export default Homeemp;