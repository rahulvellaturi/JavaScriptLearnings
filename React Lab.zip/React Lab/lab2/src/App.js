import React from 'react';
// import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Route} from 'react-router-dom'
import Showemp from './show_employee';
import Update from './update';
import Add from './add_emp';
import Homeemp from './home';
import Search from './search';
import Showsearch from './showsearch';

function App() {
  return (
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
    <BrowserRouter>
      <div>
        <Route path='/' component={Homeemp}/>
        <Route path='/show' component={Showemp}/>
        <Route path="/update" component={Update}/>
        <Route path='/add' component={Add}/>
        <Route path='/search'component={Search}/>
        <Route path='/showSearch'component={Showsearch}/>
      </div>
    </BrowserRouter>
  );
}

export default App;
