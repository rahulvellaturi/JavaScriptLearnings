import React,{Component} from 'react';
import Axios from 'axios';

class Add extends Component {
    
    addEmployee = () =>{
        let i =this.refs.eid.value;
        let n = this.refs.ename.value;
        let s = this.refs.esal.value;
        let d = this.refs.edep.value;
        let emp = {id:i,name: n, salary: s, dep: d};
        Axios.post('http://localhost:4001/add', emp)
        .then(()=>{
        this.props.history.push('/')
        })
       
    }
    render() {
        return(
            <div>
                <table className="table table-striped">
                    <tr>
                    <td>ID:</td>
                    <td><input type="number" ref="eid" name="id"/></td>
                    </tr>
                    <tr>
                        <td>Name:</td>
                        <td><input type="text" ref="ename" name="name"/></td>
                    </tr>
                    <tr>
                        <td>Salary:</td>
                        <td><input type="text" ref="esal" name="salary"/></td>
                    </tr>
                    <tr>
                        <td>Department:</td>
                        <td><input type="text" ref="edep" name="dep"/></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><button onClick={this.addEmployee} className="btn btn-success">Add</button></td>
                    </tr>
                </table>
            </div>
        )
    }
}
export default Add;