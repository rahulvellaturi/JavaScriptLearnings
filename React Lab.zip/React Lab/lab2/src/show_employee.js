import React,{Component} from 'react';
import Axios from 'axios';
import {Link} from 'react-router-dom'

class Showemp extends Component {
    state = {
        employee:[]
    }

    constructor() {
        super()
        Axios.get('http://localhost:4001/show')
        .then((res)=>this.setState({employee: res.data}))
    }
    deleteEmployee = (empid)=> {
        Axios.delete('http://localhost:4001/delete/'+empid)
        .then(()=>{
            window.location.reload("/");
        })
    }
    render() {
        return(
            <div>
                <table className="table table-striped">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Salary</th>
                        <th>Department</th>
                        <th></th>
                        <th></th>
                    </tr>
                    {this.state.employee.map((e,i)=>(
                        <tr key={i}>
                            <td>{e.empid}</td>
                            <td>{e.empname}</td>
                            <td>{e.empsal}</td>
                            <td>{e.empdep}</td>
                            <td><Link to = {{pathname: '/update/', state: {employee: e}}} className="btn btn-primary">Update</Link></td>
                            <td><button onClick={()=>this.deleteEmployee(e.empname)} className="btn btn-danger">Delete</button></td>
                        </tr>
                    ))}
                </table>
            </div>
        )
// <Link to= '/add' className="btn btn-success">Add Employee</Link>    

    }
}
export default Showemp;