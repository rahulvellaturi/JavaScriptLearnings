var express = require('express') ;
var mdb = require('mongodb');
var cors = require('cors');
var bp = require('body-parser')
var url = 'mongodb://localhost:27017/fullstack'

var app = express();
app.use(cors());
app.use(bp.urlencoded({extended: true}))
app.use(bp.json())
app.listen(4001, ()=>console.log('server started....'))

app.get('/show',(req, res)=>{
    mdb.connect(url, (err, dao)=>{
        if (err) throw err;
        dao.db('fullstack').collection('employee').find().toArray((err, result)=>{
            return res.send(result)
        })
    })
})
app.post('/add',(req,res)=>{
    mdb.connect(url, (err, dao)=>{
        if (err) throw err;
        let e = {empid: req.body.id, empname: req.body.name, empsal:req.body.salary, empdep: req.body.dep}
        dao.db('fullstack').collection('employee').insertOne(e, (err, msg)=>{
            return res.send('added')
        })
    })
})
app.put('/update/:name',(req,res)=>{
    mdb.connect(url, (err,dao)=>{
        if (err) throw err;
        dao.db('fullstack').collection('employee').updateOne({empname: req.params.name}, {$set: {empdep: req.body.dep, empsal: req.body.sal}},(err, msg)=>{
            return res.send('updated')
        })
    })
})
app.get('/search/:id',(req,res)=>{
    mdb.connect(url,(err,dao)=>{
        if (err) throw err;
        dao.db('fullstack').collection('employee').findOne({empid:parseInt(req.params.id)},(err,result)=>{
            return res.send(result)
        })
    })
})
app.delete("/delete/:name",(req,res)=>{
    mdb.connect(url,(err,dbo)=>{
        dbo.db("fullstack").collection("employee").deleteOne({empname:req.params.name},(err,result)=>{
            return res.send("deleted")
        })
    })
})