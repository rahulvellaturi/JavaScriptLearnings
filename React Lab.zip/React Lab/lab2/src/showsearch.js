import React,{Component} from 'react';

class Showsearch extends Component {
    render() {
        if(this.props.location.state.employee != '')
        {
        return(
            <div>
            <table className="table table-striped">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Salary</th>
                <th>Department</th>
                <th></th>
                <th></th>
            </tr>
            <tr>
                <td>{this.props.location.state.employee.empid}</td>
                <td>{this.props.location.state.employee.empname}</td>
                <td>{this.props.location.state.employee.empsal}</td>
                <td>{this.props.location.state.employee.empdep}</td>
            </tr>
                </table>
            </div>
        )
    }
    else{
        return(
            <h1>No Employee Found</h1>
        )
    }
}
}
export default Showsearch;