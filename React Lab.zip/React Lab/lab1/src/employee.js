import React, {Component} from 'react'

class Employee extends Component {
    state = {
        id:'',
        name:'',
        salary:'',
        department:''
    }
    // user = '';
    showAlert = () =>{
       alert(this.refs.eid.value+" "+this.refs.ename.value+" "+this.refs.esal.value+" "+this.refs.edept.value);
    }
    display = ()=>{
        let i = this.refs.eid.value;
        let n = this.refs.ename.value;
        let s = this.refs.esal.value;
        let d = this.refs.edept.value;
        this.setState({id: i, name: n, salary: s, department: d})
    }
    render() {
        return(
            <div align = "center">
            <b>Employee Form</b>
            <table className="table table-striped">
                <tr>
                    <td>ID:</td>
                    <td><input type="text" ref="eid" onChange={this.display}/></td>
                </tr>
                <tr>
                    <td>Name:</td>
                    <td><input type="text" ref="ename" onChange={this.display}/></td>
                </tr>
                <tr>
                    <td>Salary:</td>
                    <td><input type="text" ref="esal"onChange={this.display}/></td>
                </tr>
                <tr>
                    <td>Department:</td>
                    <td><input type="text" ref="edept"onChange={this.display}/></td>
                </tr>
                <tr>
                    <td></td>
                    <td><button onClick={this.showAlert} className="btn btn-success">Add Employee</button></td>
                </tr>
                <b><u>Employee Details</u></b>
                <p>{this.state.id} {this.state.name} {this.state.salary} {this.state.department}</p>
            </table>
                </div>
        )
    }
}

export default Employee;