import React,{Component} from 'react';
import Axios from 'axios';

class Books extends Component {
    state = {
        books: [],
        book:[]
    }
    searchBooks = () => {
        let bk = [];
        let id = this.refs.id.value;
        let name = this.refs.title.value;
        let author = this.refs.author.value;
        let year = parseInt(this.refs.year.value);
            if(id)
            {
                this.state.books.map((b,i)=>{
                    if(b.id==id)
                    {
                        bk.push(b)
                    }
                })
            }
            if(name)
            {
                this.state.books.map((b,i)=>{
                    if(b.title.indexOf(name)!=-1)
                    {
                        bk.push(b)
                    }
                })
            }
            if(author)
            {
                this.state.books.map((b,i)=>{
                    if(b.author.indexOf(author)!=-1)
                    {
                        bk.push(b)
                    }
                })
            }
            if(year)
            {
                this.state.books.map((b,i)=>{
                    if(b.year==year)
                    {
                        bk.push(b)
                    }
                })
            }
        this.setState({book: bk})
    }
    constructor() {
        super() 
            Axios.get('http://localhost:3000/books')
        .then((res)=>this.setState({books: res.data}))
    }
    render() {
        {
        return(
            <div align="center">
                <table border="1">
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Year</th>
                    </tr>
                    <tr>
                        <th><input type="text" ref="id" placeholder="id"onKeyUp={this.searchBooks}/></th>
                        <th><input type="text" ref="title" placeholder="title"onKeyUp={this.searchBooks}/></th>
                        <th><input type="text" ref="author"placeholder="author"onKeyUp={this.searchBooks}/></th>
                        <th><input type="text" ref="year" placeholder="year"onKeyUp={this.searchBooks}/></th>
                    </tr>
                    {this.state.book.map((b,i)=>(
                        <tr key={i}>
                            <td>{b.id}</td>
                            <td>{b.title}</td>
                            <td>{b.author}</td>
                            <td>{b.year}</td>
                        </tr>
                    ))}
                </table>
            </div>
            )
        }
    }
}
export default Books;