import React,{Component} from 'react';
import * as yup from 'yup';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import {Input, SubmitBtn, Select, Radio} from 'react-formik-ui'

class Formregister extends Component{

    //setting a variable.
    initialValues = {
        proid: '',
        proname: '',
        procost: '',
        procat: '',
        proonline:'',
        store:''
    }
    // validate schema: it is used to validate.
    signUpSchema = yup.object({
        store1: yup.bool(),
        store2: yup.bool(),
        store3: yup.bool()
    }).test('test',null, (obj)=>{
        if(obj.store1 || obj.store2 || obj.store3){return true};
        return new yup.ValidationError('Store is required',null,'store')
    }).shape({
        proid: yup.string().required('Product id is required'),
        proname: yup.string().required('Product Name is required'),
        procost: yup.string().required('Product Cost is required'),
        procat: yup.string().required('Product Category is required'),
        proonline: yup.string().required('product online is required'),
        // language: yup.string().required()
    })
    //show data when user clicks on button.
    onFormSubmit = (data)=>{
        alert(JSON.stringify(data))
    }

    render() {
        return(
            <div>
                <Formik initialValues={this.initialValues} validationSchema={this.signUpSchema} onSubmit={this.onFormSubmit}
                render = {()=>(
                    <Form>
                        <Input name="proid" label="Product ID: " type="text"/>
                        <Input name="proname" label="Product Name: " type="text"/>
                        <Input name="procost" label="Product Cost: "type="text"/>
                        <Radio name="proonline" label="Product Online: "
                            options={[
                                {value: 'yes', label: 'Yes'},
                                {value: 'no', label:'No'}
                            ]}
                        />
                        <Select name="procat" label="Product Category: " 
                        options={[
                            {value:'', label: 'Select category'},
                            {value: 'grocery', label: 'Grocery'},
                            {value: 'mobile', label: 'Mobile'},
                            {value: 'electronics', label: 'Electronics '},
                            {value: 'cloths', label: 'Cloths'}
                        ]}/>                        
                        <label>Available in Store: </label>
                        <Field type='checkbox' name="store1" value="bbz"/>Big Bazar
                        <Field type='checkbox' name="store2" value="dmt"/>DMart
                        <Field type='checkbox' name='store3' value='rel'/>Reliance<br/>
                        <ErrorMessage name="store"/><br/>
                        <SubmitBtn/>
                    </Form>
                )}
                />
            </div>
        )
    }
}
export default Formregister;