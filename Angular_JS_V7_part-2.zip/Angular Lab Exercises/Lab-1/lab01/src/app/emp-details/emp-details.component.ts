import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.css']
})
export class EmpDetailsComponent implements OnInit {
  id;
  name;
  salary;
  department;



  constructor() { }

  ngOnInit() {
  }

  addemployee()
  {
    alert(this.id + " " + this.name + " " + this.salary + " " + this.department);
  }
}
