import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {
  employee;
  eid;
  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute) {

    this.route.params.subscribe((parameters) =>{
      this.eid = parameters['id'];
    })
    this.http.get('http://localhost:3000/employee/' +this.eid)
    .subscribe((data)=>{
      this.ename = data.name;
      this.esal = data.salary;
      this.edept = data.department;
    })
   }
   ename;
   esal;
   edept;

   updateEmployee()
   {
     var json = {name: this.ename, salary: this.esal, department:this.edept};
     var header = new HttpHeaders({'Content-Type': 'application/json'});
     this.http.put('http://localhost:3000/employee/'+this.eid, json, {headers: header})
     .subscribe(
       ()=>{
         alert('updated successfully');
         this.router.navigate(['/view'])
       }
     )


   }

  ngOnInit() {
  }

}
