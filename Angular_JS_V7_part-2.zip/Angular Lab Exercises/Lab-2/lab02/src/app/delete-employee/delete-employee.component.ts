import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.css']
})
export class DeleteEmployeeComponent implements OnInit {

  constructor(private http: HttpClient, private router: Router, private activatedRoute: ActivatedRoute) {
    let eid;
    this.activatedRoute.params.subscribe((parameters)=>{
      eid = parameters['id'];
    })
    this.http.delete('http://localhost:3000/employee/' + eid)
    .subscribe(
      () => {
        alert('deleted successfully');
        this.router.navigate(['/view'])
      }
    )
   }
  ngOnInit() {
  }

}
