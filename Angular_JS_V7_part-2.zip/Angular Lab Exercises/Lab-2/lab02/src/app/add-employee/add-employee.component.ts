import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  eid;
  ename;
  esal;
  edept;
  addEmployee()
  {
    var json = {id: this.eid, name:this.ename, salary:this.esal, department: this.edept};
    var header = new HttpHeaders({'Content-Type':'application/json'});
    this.http.post('http://localhost:3000/employee', json, {headers:header})
    .subscribe(() => {
      alert('added successfully');
      this.router.navigate(['/view'])
    }
    )
  }

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit() {
  }

}
