import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewCourseComponent } from './view-course/view-course.component';
import { AddCourseComponent } from './add-course/add-course.component';
import { CourseDurationComponent } from './course-duration/course-duration.component';
import { CoursesComponent } from './courses/courses.component';
import { CourseJsonComponent } from './course-json/course-json.component';

const routes: Routes = [
  // {path:'', redirectTo:'/view', pathMatch:'full'},
  {path:'add', component:AddCourseComponent},
  {path:'view', component:ViewCourseComponent},
  {path:'courseJson', component:CourseJsonComponent},
  {path:'',component:CoursesComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
