import { TestBed } from '@angular/core/testing';

import { CourseplayService } from './courseplay.service';

describe('CourseplayService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CourseplayService = TestBed.get(CourseplayService);
    expect(service).toBeTruthy();
  });
});
