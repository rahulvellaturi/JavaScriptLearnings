import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule}from '@angular/forms';
import {HttpClientModule}from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewCourseComponent } from './view-course/view-course.component';
import { AddCourseComponent } from './add-course/add-course.component';
import { CourseDurationComponent } from './course-duration/course-duration.component';
import { SearchPipe } from './search.pipe';
import { from } from 'rxjs';
import { CourseJsonComponent } from './course-json/course-json.component';
import { CoursesComponent } from './courses/courses.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewCourseComponent,
    AddCourseComponent,
    CourseDurationComponent,
    SearchPipe,
    CourseJsonComponent,
    CoursesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
