import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CourseplayService {

  courses=[
    {name:"Course 1",duration:"1"},
    {name:"Course 2",duration:"2"},
    {name:"Course 3",duration:"3"},
    {name:"Course 4",duration:"2"},
    {name:"Course 5",duration:"1"},
    {name:"Course 6",duration:"1"}

  ];
  getAllCourses(){
    return this.courses;
  }

  add(n,d){
    this.courses.push({name:n,duration:d})
  }
  // course_details;
  getCourses(){
    return this.http.get("http://localhost:3000/courses")
  }

  constructor(private http:HttpClient) {   }

}
