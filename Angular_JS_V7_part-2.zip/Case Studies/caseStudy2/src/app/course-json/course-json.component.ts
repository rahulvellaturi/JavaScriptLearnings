import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CourseplayService } from '../courseplay.service';

@Component({
  selector: 'app-course-json',
  templateUrl: './course-json.component.html',
  styleUrls: ['./course-json.component.css']
})
export class CourseJsonComponent implements OnInit {

  
  course_details;
  // constructor(private http:HttpClient) {
  //   this.http.get("http://localhost:3000/courses")
  //   .subscribe(
  //     (data)=>this.course_details=data
  //   )
  //     return this.course_details;

  //  }
  constructor(private bs:CourseplayService){
    bs.getCourses().subscribe((data)=>{
      this.course_details=data;
  })
  }
  ngOnInit() {
  }

}
