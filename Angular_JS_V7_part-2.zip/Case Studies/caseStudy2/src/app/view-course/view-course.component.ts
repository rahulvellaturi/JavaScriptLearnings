import { Component, OnInit } from '@angular/core';
// import { CoursesComponent } from '../courses/courses.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CourseplayService } from '../courseplay.service';

@Component({
  selector: 'app-view-course',
  templateUrl: './view-course.component.html',
  styleUrls: ['./view-course.component.css']
})
export class ViewCourseComponent implements OnInit {

  // courses=[
  //   {name:"Course 1",duration:1},
  //   {name:"Course 2",duration:2},
  //   {name:"Course 3",duration:3},
  //   {name:"Course 4",duration:2},
  //   {name:"Course 5",duration:1},
  //   {name:"Course 6",duration:1}

  // ];
  courses = [];
  constructor(private cs: CourseplayService) {
    this.courses = cs.getAllCourses();
   }


  cname; cduration;
  addCourse(){
    this.cs.add(this.cname,this.cduration);
    this.cname = '';
    this.cduration = '';

  }
  scname;
  getDuration(){
    for(let i=0;i<this.courses.length;i++){
      // if(value[i].city.indexOf(city)!= -1){
      if(this.courses[i].name.indexOf(this.scname)!= -1){
        alert("Duration :" +this.courses[i].duration)
      }
    }
  }
  CForm= new FormGroup({
    c1name: new FormControl('',[Validators.required]),
    c1duration: new FormControl('',[Validators.required]),
  })

  error_messages={
    'name':[{type:'required',message:'Course Name is required'}],
    'duration':[{type:'required',message:'Course Name is required'}]

  }

  ngOnInit() {
  }

}
