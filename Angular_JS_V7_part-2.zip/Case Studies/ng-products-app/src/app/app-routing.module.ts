import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewProductsComponent } from './view-products/view-products.component';
import { AddProductComponent } from './add-product/add-product.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { DeleteProductComponent } from './delete-product/delete-product.component';

const routes: Routes = [
  {path: '',redirectTo: 'view', pathMatch: 'full'},
  {path: 'view', component: ViewProductsComponent},
  {path: 'add', component: AddProductComponent},
  {path: 'edit/:id', component: EditProductComponent},
  {path: 'remove/:id', component: DeleteProductComponent},
  {path: '**', component: ViewProductsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
