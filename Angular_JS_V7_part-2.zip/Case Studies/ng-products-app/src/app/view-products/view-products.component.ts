import { Component, OnInit } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.css']
})
export class ViewProductsComponent implements OnInit {

  prod_details;
  constructor(private http:HttpClient) {
    this.http.get("http://localhost:3000/products")
    .subscribe(
      (data)=>this.prod_details=data
    )
   }

  ngOnInit() {
  }

}
