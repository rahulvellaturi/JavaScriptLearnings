import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  pid;
  pname;
  desc;
  price;


  addProd(){
    var json ={id:this.pid,name:this.pname,Desc:this.desc,price:this.price};
    var header=new HttpHeaders({'Content-Type':'application/json'});
    this.http.post('http://localhost:3000/products',json,{headers:header})
    .subscribe(()=>{
      alert("added successfully");
      this.router.navigate(['/view'])
    })
  }

  constructor( private http:HttpClient,private router:Router) { }

  ngOnInit() {
  }

}
