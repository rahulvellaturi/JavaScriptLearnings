import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {

  transform(value, type): any {


    if(type == "low")
    {
      for(let i=0;i<value.length;i++)
      {
        return value.sort((a,b)=>{

          if(a.price > b.price)
          {
            return 1;
          }
          if(a.price < b.price)
          {
            return -1;
          }
          else
          {
            return 0;
          }
        })
      }
    }
    if(type == "high")
    {
      for(let i=0;i<value.length;i++)
      {
        return value.sort((a,b)=>{

          if(a.price > b.price)
          {
            return -1;
          }
          if(a.price < b.price)
          {
            return 1;
          }
          else
          {
            return 0;
          }
        })
      }
    }

  }

}
