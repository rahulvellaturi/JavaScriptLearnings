import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-show-product',
  templateUrl: './show-product.component.html',
  styleUrls: ['./show-product.component.css']
})
export class ShowProductComponent implements OnInit {

  product_details;
  prices ;

  constructor(private http:HttpClient , private cd:ProductsService) {

    this.product_details = this.cd.getDetails()
    .subscribe((data)=>{

      this.product_details = data;
    })
  }



  ngOnInit() {
  }

}
