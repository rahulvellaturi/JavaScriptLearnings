import { Component, OnInit } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  id;
  name;
  price;
  des;
  constructor(private http:HttpClient,private router:Router) { }


  addProduct()
  {
        var json = {id:this.id,name:this.name,price:this.price,description:this.des}
        var head = new HttpHeaders({'Content-Type' : 'application/json'})
        this.http.post("http://localhost:3000/product/",json,({headers:head}))

        .subscribe(()=>{

          alert("added successfully");
          this.router.navigate(['/show'])
        })
  }

  ngOnInit() {
  }

}
