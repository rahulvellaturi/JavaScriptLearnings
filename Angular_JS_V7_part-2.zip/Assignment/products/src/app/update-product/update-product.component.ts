import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {

  name;
  price;
  des;
  prdtid;
  product: Object;
  id: any;
  constructor(private http:HttpClient,private router:Router,private rour:ActivatedRoute) {


    this.rour.params.subscribe((parameters)=>{

      this.prdtid = parameters['pid'];
    })
    this.http.get(' http://localhost:3000/product/'+this.prdtid)
    .subscribe((data) => {
      this.product = data;
      this.getById();
    })
  }
    getById()
    {
      this.name = this.product.pname;
      this.price = this.product.pprice;
      this.des = this.product.pdescription;
    }

  updateProduct()
  {
    var json = {id:this.id,name:this.name,price:this.price,description:this.des}
    var head = new HttpHeaders({'Content-Type' : 'application/json'})

    this.http.put('http://localhost:3000/product/' + this.prdtid,json,({headers:head}))

    .subscribe(()=>{

      alert("updated successfully");
      this.router.navigate(['/show'])
    })
  }

  ngOnInit() {
  }
}
