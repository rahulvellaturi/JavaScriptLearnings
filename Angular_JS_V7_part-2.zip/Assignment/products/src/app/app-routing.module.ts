import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddProductComponent } from './add-product/add-product.component';
import { ShowProductComponent } from './show-product/show-product.component';
import { DeleteProductComponent } from './delete-product/delete-product.component';
import { UpdateProductComponent } from './update-product/update-product.component';

const routes: Routes =
[
  {path: '', redirectTo: 'show', pathMatch: 'full'},
  {path: 'add', component: AddProductComponent},
  {path: 'show', component: ShowProductComponent},
  {path: 'delete/:pid', component: DeleteProductComponent},
  {path: 'update/:pid', component: UpdateProductComponent},
  {path: '**', component: ShowProductComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
