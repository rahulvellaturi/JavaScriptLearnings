import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-delete-product',
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.css']
})
export class DeleteProductComponent implements OnInit {

  prdtid;
  constructor(private http:HttpClient,private rout:ActivatedRoute,private cd:ProductsService) {


    this.rout.params.subscribe((parameters)=>{

      this.prdtid = parameters['pid'];
    })

      this.cd.deleteProduct(this.prdtid)
  }

  ngOnInit() {
  }

}
