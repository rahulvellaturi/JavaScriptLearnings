import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  address;
  constructor(private cm:BookService) {
    this.cm.getAddress().subscribe(
      (data)=>
      {
        this.address=data
      }
    ) 
}

  ngOnInit() {
  }

}
