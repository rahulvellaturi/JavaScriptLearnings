import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BookService } from '../book.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
 address
  constructor(private cm:BookService) {
    this.cm.getAddress().subscribe(
      (data)=>
      {
        this.address=data
      }
    ) 

  }

  ngOnInit() {
  }

}
