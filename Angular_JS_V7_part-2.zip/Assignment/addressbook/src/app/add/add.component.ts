import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  bname;
  city;
  bphoneno;
  constructor(private http:HttpClient,private router:Router) { }
  addAddress(){
    var json={name:this.bname,city:this.city,phoneno:this.bphoneno};
    var header=new HttpHeaders({'Content-type':'application/json'});
    this.http.post(" http://localhost:3000/books",json,{headers:header})
    .subscribe(()=>{
      alert('address added')
      alert(this.bname+" "+this.city+" "+this.bphoneno)
      this.router.navigate(['/show'])
    })
  }

  ngOnInit() {
  }

}
