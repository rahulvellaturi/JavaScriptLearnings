import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(value,aid,aname,acity,aphoneno){
    let ba=[];
    if(aid!=''){
      for(let i=0;i<value.length;i++){
      if(value[i].id==aid){
      ba.push(value[i]);
    }
  }
  }
   if(aname!=''){
      for(let i=0;i<value.length;i++){
        if(value[i].name.indexOf(aname)!=-1){
        ba.push(value[i]);
    }
  }
  }
  if(acity!=''){
    for(let i=0;i<value.length;i++){
      if(value[i].city.indexOf(acity)!=-1){
      ba.push(value[i]);
  }
  }
  }
  if(aphoneno!=''){
    for(let i=0;i<value.length;i++){
      if(value[i].phoneno==aphoneno){
      ba.push(value[i]);
  }
}
}
return ba;
}
}
