import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { HttpHeaders,HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  add_id;
  add_name;
  add_city;
  add_phoneno;

  constructor( private http:HttpClient,private router:Router,private route:ActivatedRoute) {
    this.route.params.subscribe((parameters)=>{
      this.add_id=parameters['id'];
    })
    this.http.get(' http://localhost:3000/books/'+this.add_id)
    .subscribe((data)=>{
      // this.add_name = data.name;
      // this.add_city = data.city;
      // this.add_phoneno = data.phoneno;
    })
  }
  updateAddress(){
    var json={name:this.add_name,city:this.add_city,phoneno:this.add_phoneno}
    var header=new HttpHeaders({'Content-type':'application/json'});
    this.http.put(" http://localhost:3000/books/"+this.add_id,json,{headers:header})
    .subscribe(()=>{
      alert('updated added')

      this.router.navigate(['/show'])
    })
  }

  ngOnInit() {
  }

}
