import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowComponent } from './show/show.component';

import { AddComponent } from './add/add.component';
import { MenuComponent } from './menu/menu.component';
import { DeleteComponent } from './delete/delete.component';
import { SearchComponent } from './search/search.component';
import { UpdateComponent } from './update/update.component';

const routes: Routes = [
  {path:'',component:MenuComponent},
  {path:'add',component:AddComponent},
  {path:'delete/:id',component:DeleteComponent},
  {path:'update/:id',component:UpdateComponent},
  {path:'search',component:SearchComponent},
  {path:'show',component:ShowComponent},
  {path:'**',component:ShowComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
