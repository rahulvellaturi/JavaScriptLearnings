import { Component, OnInit } from '@angular/core';
import { MoviesService } from 'src/movies.service';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {

  constructor(private ms: MoviesService) { }

  ngOnInit() {
  }
  mname;
  grate;
  gselect;
  addMovie(){
    this.ms.addmovie(this.mname, this.grate, this.gselect)
    .subscribe(()=>alert('added successfully'))
  }
}
