import { Component, OnInit } from '@angular/core';
import { MoviesService } from 'src/movies.service';

@Component({
  selector: 'app-search-movie',
  templateUrl: './search-movie.component.html',
  styleUrls: ['./search-movie.component.css']
})
export class SearchMovieComponent implements OnInit {

  constructor(private ms: MoviesService) { }

  ngOnInit() {
  }

  geselect;
  searchm;

  search(){
     this.ms.searchmovie(this.geselect)
      .subscribe(data=>{
      this.searchm = data;
    })


  }

}
