var express = require("express");
var mdb = require("mongodb");
var bp = require("body-parser");
var cors = require("cors");
var url = "mongodb://localhost:27017/fullstack"

var app = express();
app.use(bp.urlencoded({extended: true}));
app.use(bp.json());
app.use(cors());

app.listen(3000, ()=> console.log("server started...."))


app.post('/addMovie', (req,res)=>{
  var p = {name: req.body.name, rating: req.body.rate, genre: req.body.genre}
  mdb.connect(url, (err,dao)=>{
    dao.db('fullstack').collection('movie').insertOne(p, (err,result)=>{
      return res.json(result);
    })
  })
})
app.get('/searchMovie/:s', (req,res)=>{
  mdb.connect(url, (err,dao)=>{
    var sm = req.params.s;
    dao.db('fullstack').collection('movie').find({genre : sm}).toArray((err,msg)=>{
      return res.json(msg);
    })
  })
})
