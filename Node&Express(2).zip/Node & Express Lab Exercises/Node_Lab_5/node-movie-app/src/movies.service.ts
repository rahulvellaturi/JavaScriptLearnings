import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {

  constructor(private http: HttpClient) { }

  addmovie(name, rating, select) {
    var body = {mname: name, grate: rating, gselect: select}
    var header = new HttpHeaders({'Content-Type':'application/json'})
    return this.http.post('http://localhost:3000/addMovie', body,{headers: header})
  }

  searchmovie(s){

    return this.http.get('http://localhost:3000/searchMovie/'+s)
  }
}
