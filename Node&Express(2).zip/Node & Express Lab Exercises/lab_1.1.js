//1.1 Create a prob1.js containing script. In this script, declare an array of 6 employee names and display it in the console using node.
var mongo = require("mongodb").MongoClient

var url = "mongodb://localhost:27017/fullstack"
// var url = "mongodb://127.0.0.1:27017/fullstack"

mongo.connect(url, (err,database)=>{
    if (err) throw err;
    console.log('connected....')
    // Create a collection.
    var d = database.db('fullstack').createCollection("empl",(err, res)=>{
        if (err) throw err;
        console.log("Collection created successfully....")
    })
    let emp = [
        {_eid: 1, ename: "Raj"},
        {_eid: 2, ename: "Ram"},
        {_eid: 3, ename: "Rajesh"},
        {_eid: 4, ename: "Rahul"},
        {_eid: 5, ename: "Ramesh"},
        {_eid: 6, ename: "Rajeev"},
    ]
    //     database.db('fullstack').collection('empl').insert(emp, (err, msg)=>{
    //     if (err) throw err;
    //     console.log(msg)
    // })
    // database.db('fullstack').collection('empl').find().toArray((err, result)=>{
    //     if (err) throw err;
    //     console.log(result);
    // })
    emp.forEach(e =>{
        console.log(e.ename);
    });
})