//1.2 Create  a node server read the data from the file and display on the console.
var file = require('fs')
file.readFile('sample.txt', (err,res)=>{
    if (err) throw err;
    console.log(res.toString());
})