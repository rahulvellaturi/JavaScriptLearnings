var express = require('express')
var pug = require('pug');
var path = require('path');
var mdb = require('mongodb');
var bp = require('body-parser')
var url = 'mongodb://127.0.0.1:27017/fullstack'
var app = express();
app.set('view engine','pug')
app.listen(9099, ()=>console.log('server started....'))
app.use(express.static(path.join(__dirname, 'public')))
app.use(bp.urlencoded({extended: true}))
app.use(bp.json())
// var url = "mongodb://localhost:27017/fullstack"


    
// var d = database.db('fullstack').createCollection("employees",(err, res)=>{
//     if (err) throw err;
//     console.log("Collection created successfully....")


  app.get('/',(req,res)=>{
    // res.render('home')
    mdb.connect(url, (err,dao)=>{
        dao.db('fullstack').collection('magicbook').find().toArray((err, result)=>{
            if(err) throw err;
            res.render('index', {shows: result});
        })
    })
})

app.get('/book/:name',(req,res)=>{
    mdb.connect(url, (err,dao)=>{
        if(err) throw err;
        dao.db('fullstack').collection('magicbook').findOne({showName:req.params.name},(err,result)=>{
            res.render('booknow',{movieinfo:result})
            })
        })
    })
    app.post('/bookno',(req,res)=>{
        mdb.connect(url, (err, dao)=>{
            dao.db('fullstack').collection('magicbook').updateOne({showName:req.body.sname},{$set:{savail:parseInt(req.body.seats)-parseInt(req.body.nseats)}},(err,msg)=>{
                res.render('success',{details:req.body});
            })
        })
    })
