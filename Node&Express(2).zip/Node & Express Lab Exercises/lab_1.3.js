//1.3 Create a node server write the data into the file.
var file = require('fs')
var d = "hello rahul..."
    file.writeFile('hello.txt',d,(err,data)=>{
        if(err) throw err;
        console.log(d.toString())
    })
