//  //2. Mongo DB with Node JS

// var mongo = require("mongodb").MongoClient

// var url = "mongodb://localhost:27017/fullstack"
//   //var url = "mongodb://127.0.0.1:27017/fullstack"

// mongo.connect(url, (err,database)=>{
    // if (err) throw err;
    // console.log('connected....')
    // Create a collection
    // var d = database.db('fullstack').createCollection("products",(err, res)=>{
    //     if (err) throw err;
    //     console.log("Collection created successfully....")
    // })
    // var p = {_pid: 1, pname: "pen", pcost: 50, pdesc: "stationary"}
    // database.db('fullstack').collection('products').insert(p, (err, msg)=>{
    //     if (err) throw err;
    //     console.log(msg)
    // })
    // let pro = [
    //     {_pid: 2, pname: "pencil", pcost: 30, pdesc: "stationary"},
    //     {_pid: 3, pname: "moto e", pcost: 10000, pdesc: "mobile"},
    //     {_pid: 4, pname: "moto g6", pcost: 25000, pdesc: "mobile"},
    // ]
    // database.db('fullstack').collection('products').insert(pro, (err, msg)=>{
    //     if (err) throw err;
    //     console.log(msg)
    // })


    //  //a.    retrive or get data from db
    // database.db('fullstack').collection('products').find().toArray((err, result)=>{
    //     if (err) throw err;
    //     console.log(result);
    // })

    //  //b.    get data based on product id ?
    // database.db('fullstack').collection('products').find({_pid: 3}).toArray((err, result)=>{
    //     if (err) throw err;
    //     console.log("product data:")
    //     console.log(result);
    // })

    //  //c.  delete data based on product id ?
    // database.db('fullstack').collection('products').remove({_pid: 4}, (err, result)=>{
    // console.log('removed....')
    // })

    //  //d.  update data based on product id ?
    // database.db('fullstack').collection('products').update({_pid: 3},{$set:{ pcost: 12000}},(err, result)=>{
    // console.log('updated....');
    // })
// })
