// var mdb = require ('mongodb');
// var bp = require('body-parser');
// var express = require('express');

// var app = express();
// app.listen(9090, ()=>console.log('server started....'))
// app.use(bp.urlencoded({extended: true}));
// app.use(bp.json());
// var url = "mongodb://localhost:27017/fullstack"


// //  // checking if database is connected or not
// // mdb.connect(url, (err,dao)=>{
// //     if(err) throw err;
// //     console.log('connected to db fullstack....')
// // })

// app.get('/employees', (req,res)=>{
//     mdb.connect(url, (err,dao)=>{
//         if (err) throw err;
//         dao.db('fullstack').collection('employees').find().toArray((err, data)=>{
//             res.send(data);
//             res.end();
//         })
//     })
// })





var mongo = require("mongodb").MongoClient
var url = "mongodb://127.0.0.1:27017/fullstack"
mongo.connect(url, (err,database)=>
{
    if(err) throw err;
    console.log('Connected!!!')
    database.db('fullstack').collection('employees').find().toArray((err,result)=>
    {
        if(err)throw err;
        console.log(result);
    })
    // database.db('fullstack').collection('employees').find({'empAddress.state':'California'}).toArray((err,result)=>
    // {
    //     if(err)throw err;
    //     console.log(result);
    // })
    database.db('fullstack').collection('employees').update({empName:'Terena'},{$set:{"empAddress.city":'Manhattan'}},(err,res)=>
    {
        console.log('updated...!')
    })
    // var r=[
    //     {
    //         "empId": 1008,
    //         "empName": "Hari",
    //         "empSalary": 59000,
    //         "empAddress": {
    //             "city": "Coimbatore",
    //             "state": "Tamil Nadu"
    //             }
    //     }
    // ]
    // database.db('fullstack').collection('employee').insert(r,(err,msg)=>{
    //     if(err)throw err;
    //     console.log(msg)
    // })
   
})


