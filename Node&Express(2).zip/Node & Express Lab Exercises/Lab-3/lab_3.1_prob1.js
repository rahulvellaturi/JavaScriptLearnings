var mongo = require("mongodb").MongoClient
var bp = require('body-parser');
var express = require('express');

var app = express();
// app.listen(9091, ()=>console.log('server started....'))
app.use(bp.urlencoded({extended: true}));
app.use(bp.json());

app.listen(9091, ()=> console.log("server listening at http://localhost:9091"))

var url = "mongodb://localhost:27017/fullstack"

mongo.connect(url, (err,database)=>{
    if (err) throw err;
    console.log('connected....')

// // inserting one employees to the document.
// app.post('/employees', (req,res)=>{
//     mdb.connect(url, (err,dao)=>{
//         if (err) throw err;
//         var c = {empName: req.body.empName, empSalary: req.body.empSalary, empAddress: req.body.empAddress}
//         dao.db('fullstack').collection('employees').insertOne(c, (err,msg)=>{
//             res.send('document inserted....')
//             res.end();
//         })
//     })
// })

var d = database.db('fullstack').createCollection("employees",(err, res)=>{
        if (err) throw err;
        console.log("Collection created successfully....")
})


let employees = [
  {
    "empId": 1001,
    "empName": "Jack",
    "empSalary": 40000,
    "empAddress": {
      "city": "Pune",
      "state": "Maharashtra"
    }
  },
      {
        "empId": 1002,
        "empName": "Jill",
        "empSalary": 42000,
        "empAddress": {
          "city": "Nashik",
          "state": "Maharashtra"
        }
      },
      {
        "empId": 1003,
        "empName": "Sebastian",
        "empSalary": 14000,
        "empAddress": {
          "city": "Agra",
          "state": "Uttar Pradesh"
        }
      },
      {
        "empId": 1004,
        "empName": "Jessica",
        "empSalary": 30000,
        "empAddress": {
          "city": "Lucknow",
          "state": "Uttar Pradesh"
        }
      },
      {
        "empId": 1005,
        "empName": "Terena",
        "empSalary": 45000,
        "empAddress": {
          "city": "San Diego",
          "state": "California"
        }
      },
     {
        "empId": 1006,
        "empName": "Aadel",
        "empSalary": 50000,
        "empAddress": {
          "city": "San Jose",
          "state": "California"
        }
      },
    ]

//   employees.forEach(emp => {
//       console.log(emp);
//   });
  
// 1. Displaying ALL Employees
app.get('/employees', (req,res)=>{
    mongo.connect(url, (err,dao)=>{
        if (err) throw err;
        dao.db('fullstack').collection('employees').find().toArray((err, data)=>{
            res.send(data);
            res.end();
        })
    })
})

// 2.  Displaying employees belonging to a specific state.
app.get('/employees/:state', (req,res)=>{
    mdb.connect(url, (err,dao)=>{
        if (err) throw err;
        dao.db('fullstack').collection('employees').find({state: req.params.state}).toArray((err, data)=>{
            res.send(data);
            res.end();
        })
    })
})

// //Deleting employee.
// app.delete('/employees/:empName', (req,res)=>{
//     mongo.connect(url, (err,dao)=>{
//         if (err) throw err;
//         dao.db('fullstack').collection('employees').deleteOne({empName: req.params.empName},(err,data)=>{
//         res.send('deleted successfully....')
//         res.end();
//         })
//     })
// })

// 3.  Updating city of a particular employee.
app.put('/employees/:name',(req,res)=>{
        mongo.connect(url,(err,dao)=>
        {
            if(err)throw err
            dao.db('fullstack').collection('employees').updateOne({empName:req.params.name},{$set:{"empAddress.city":"Lucknow"}},(err,msg)=>{
                res.send('Updated successfully....');
                res.end();
            })
        })
    })
    
 // 4.  Adding a new employee.
app.post('/employees', (req,res)=>{
    mongo.connect(url, (err,dao)=>{
        if (err) throw err;
        var e = {empId:req.body.empId, empName: req.body.empName, empSalary: req.body.empSalary, empAddress: {city:req.body.empAddress.city,state:req.body.empAddress.state}}
        dao.db('fullstack').collection('employees').insertOne(e, (err,msg)=>{
            res.send('document inserted....')
            res.end();
        })
    })
})
})