//1.4 Create a Web Application using node where user can enter username ,password & by using request & response data will transfer to next page.
var http = require('http')

var url = require('url')


var server = http.createServer((req,res)=>{
   
    var q = url.parse(req.url, true);
    var d = q.query;
    res.writeHead(200, {"content-type":"text/html"})
    res.write("Username:"+d.name+"<br>")
    res.write("Password:"+d.password+"<br>")
    res.end();
})

server.listen(9001, ()=> console.log('server listning at http://localhost:9000'))
