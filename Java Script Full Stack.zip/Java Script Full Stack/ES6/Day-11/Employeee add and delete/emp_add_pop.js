let e = new Set();
function addEmployee(n)
{
    for(let i =1; i<=n; i++)
    {
        let id = prompt("enter id:");
        let name = prompt("enter name:");
        let description = prompt("enter description");
        let p1 = {id: id, name: name, description: description};
        e.add(p1);
        alert("employee " + i + "added successfully");
    }
}
function showAll()
{
    e.forEach((p)=>document.write("<br>ID: "+ p.id + " <br> Name:" + p.name + " <br> Description: " + p.description));
}
//Deleting an object.
function remove(pid)
{
    let e1 = Array.from(e);
    e1.map((p,i)=>{
        if (p.id == pid)
        {
            e1.splice(i, 2);
            alert("deleted....")
        }
    })
    e = new Set(e1);
}