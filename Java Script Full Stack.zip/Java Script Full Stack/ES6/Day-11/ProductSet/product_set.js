let s = new Set();
function addProduct(n)
{
    for(let i =1; i<=n; i++)
    {
        let id = prompt("enter id:");
        let name = prompt("enter name:");
        let description = prompt("enter description");
        let p1 = {id: id, name: name, description: description};
        s.add(p1);
        alert("product " + i + "added successfully");
    }
}
function showAll()
{
    s.forEach((p)=>document.write("<br>ID: "+ p.id + " <br> Name:" + p.name + " <br> Description: " + p.description));
}
//Deleting an object.
function remove(pid)
{
    let s1 = Array.from(s);
    s1.map((p,i)=>{
        if (p.id == pid)
        {
            s1.splice(i, 2);
            alert("deleted....")
        }
    })
    s = new Set(s1);
}