class Person
{
    name = '';
    age = 0;
    constructor(name,age)
    {
        this.name = name;
        this.age = age;

    }
    printAll()
    {
        document.write(this.name + " " + this.age);
    }
}