class Student extends Person
{
    university = '';
    constructor(name,age,university)
    {
        super(name,age)
        this.university = university;
    }
    printAll()
    {
        document.write("<br>" + this.name + " " +this.age+ " " + this.university)
    }

}
let s1 = new Student('Rahul', 25, 'Capgemini')
s1.printAll()