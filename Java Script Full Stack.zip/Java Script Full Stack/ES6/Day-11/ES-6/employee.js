class Employee extends Person
{
    salary = 0;
    designation = " ";
    constructor(name,age,salary,designation)
    {
        super(name,age,salary,designation)
        this.salary = salary;
        this.designation = designation;
    }
    printAll()
    {
        document.write("<br>"+this.name+ " " + this.age + " " +this.salary + " " + this.designation + " ")
    }
}
let e1 = new Employee("Rahul",22,50000,"Fresher")
e1.printAll()