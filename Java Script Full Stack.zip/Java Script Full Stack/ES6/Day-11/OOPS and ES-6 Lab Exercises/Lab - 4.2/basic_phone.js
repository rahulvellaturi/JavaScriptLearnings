class BasicPhone extends Mobile
{
    color = '';
    constructor(id,name,cost,color)
    {
        super(id,name,cost)
        this.color = color;
    }
    printAll()
    {
        document.write("<br>" + this.id + " " +this.name+ " " + this.cost +""+ this.color)
    }

}
let m1 = new BasicPhone(123,"nokia",2000,"black");
m1.printAll()