class SmartPhone extends Mobile
{
    company = "";
    constructor(id,name,cost,company)
    {
        super(id,name,cost)
        this.company = company;
    }
    printAll()
    {
        document.write("<br>"+this.id+ " " + this.name + " " +this.cost + " " + this.company + " ")
    }
}
let s1 = new SmartPhone(123,"moto g",20000,"moto");
s1.printAll()