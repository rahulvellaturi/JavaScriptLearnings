class Product
{
    id = 0;
    name = '';
    price = 0;
    description = '';
    constructor(id, name, price, description)
    {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
    }
}
class Product1 extends Product
{
    type = '';
    constructor(id, name, price, description,type)
    {
        super(id, name, price, description);
        this.type = type;
    }
    printProduct1Details()
    {
        document.write(this.id+" <br> "+this.name+" <br> "+this.price+" <br> "+this.description+" <br> "+this.type+" <br> ")
    }
}
let p1 = new Product1(123,"pen",100,"wgwegwg","efwgwg");
p1.printProduct1Details();
class Product2 extends Product
{
    category = '';
    constructor(id, name, price, description,category)
    {
        super(id, name, price, description);
        this.category = category;
    }
    printProduct2Details()
    {
        document.write(this.id+" <br> "+this.name+" <br> "+this.price+" <br> "+this.description+" <br> "+this.category)
    }
}
let p2 = new Product2(1234,"book",150,"wgwegwg","efwgwg");
p2.printProduct2Details();