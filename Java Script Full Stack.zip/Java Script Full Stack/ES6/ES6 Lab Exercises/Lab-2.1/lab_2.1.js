let product = {
    id:0,
    name:'',
    price:0,
    description:'',
    display(){
        document.write(this.id + this.name + " " + this.price + " " +this.description + " " );
    }
}
let product1 = {
    type: " ",
    display(){
        document.write("<b>ID: </b>"+this.id + "<br><b> Name: </b>" + this.name + " <br><b>Price: </b>" + this.price + " <br><b>Description: </b>" +this.description + " <br><hr/> " );
    }
}
product1.__proto__=product;
product1.id = 1234;
product1.name = "pen";
product1.price = 100;
product1.description = "iguhvuiphwuigwei";
product1.display();
let product2 = {
    category: " ",
    display(){
        document.write("<b>ID: </b>" + this.id + "<br><b> Name: </b>" + this.name + "<br><b> Price: </b>" + this.price + "<br><b> Description: </b>" +this.description + " " );
    }
}
product2.__proto__=product;
product2.id = 12345;
product2.name = "book";
product2.price = 100;
product2.description = "iguhvuiphwuigwei";
product2.display();