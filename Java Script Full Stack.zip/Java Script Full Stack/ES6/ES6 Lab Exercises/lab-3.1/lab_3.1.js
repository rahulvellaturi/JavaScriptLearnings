let product=[];

function add(n)
{
    for (let i=1; i<=n; i++)
    {
        let p_id = prompt("enter id:");
        let p_name = prompt("enter name:");
        let p_price = prompt("enter price:");
        let p_description = prompt("enter description:");
        let pro = {id: p_id, name: p_name, price: p_price, description: p_description};
        let jpro = JSON.stringify(pro);
        product.push(jpro);
    }
}
function showAll()
{
    for (let pr of product)
    {
        let p = JSON.parse(pr);
        document.write("ID: " +p.id+ "<br>Name: "+p.name+" <br>Price: "+p.price+" <br>Description "+p.description);
    }
}
