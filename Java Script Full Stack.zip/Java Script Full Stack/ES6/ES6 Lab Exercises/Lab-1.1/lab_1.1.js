function Product(id,name,price,description)
{
    this.id = id;
    this.name = name;
    this.price = price;
    this.description = description;
}
    let prod = [];

function add(n)
{
    for (let i=1;i <=n; i++)
    {
        let id = prompt("enter id:");
        let name = prompt("enter name:");
        let price = prompt("enter price:");
        let description = prompt("enter description:");
        let p = new Product(id, name, price, description);
        prod.push(p);
    }
}
function showAll()
{
    for (let p of prod)
    {
        document.write("<br>id: "+p.id);
        document.write("<br>name: "+p.name);
        document.write("<br>price: "+p.price);
        document.write("<br>description: "+p.description);
    }
}