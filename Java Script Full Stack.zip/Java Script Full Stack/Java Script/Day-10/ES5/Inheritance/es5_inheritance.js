let person = {
    name:'',
    age:0,
    display(){
        document.write(this.name + " " + this.age);
    }
}

let student = {
    college_name:'',
    display(){
        document.write(this.name + " <br> " + this.age + " <br> " + this.college_name)
    }
}
let employee = {
    salary:'',
    display(){
        document.write(" <br> Name: "+this.name + "<br>" + "Age:" + this.age + "<br>" + "Salary"+ this.salary);
    }
}
student.__proto__=person;
student.name = "Rahul";
student.age = 22;
student.college_name = "Sreenidhi Institute of Science and Technology"
student.display();
employee.__proto__=person;
employee.name = "Rahul";
employee.age = 22;
employee.salary = 17000;
employee.display();