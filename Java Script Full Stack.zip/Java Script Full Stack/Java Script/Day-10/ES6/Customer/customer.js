class Customer
{
    id = 0;
    name = " ";
    city = " ";
    constructor(name, id)
    {
        this id = id;
        this name = name;
        this city = city;
    }
    display()
    {
        document.write(this.id+" "+this.name+" "+this.city);
    }
}
let c = newCustomer("rahul",22,"Hyderabad");
c.display();