class Person
{
    name = '';
    age = 0;
    constructor(name, age)
    {
        this.name = name;
        this.age = age;
    }
}
// class Student extends Person
// {
//     university = '';
//     constructor(name, age, university)
//     {
//         super(name, age);
//         this.university = university;
//     }
//     printStudentDetails()
//     {
//         document.write(this.name +" "+this.age+" "+this.university)
//     }
// }
// let s = new Student("rahul",22,"Capgemini");
// s.printStudentDetails();
class Employee extends Person
{
    salary = "";
    constructor(name, age, salary)
    {
        super(name, age, salary)
        this.salary = salary;
    }
    printEmployeeDetails()
    {
        document.write("Name: "+this.name+" <br> "+this.age+" <br> "+this.salary)
    }
}
let e = new Employee("rahul", 22, "50000");
e.printEmployeeDetails();