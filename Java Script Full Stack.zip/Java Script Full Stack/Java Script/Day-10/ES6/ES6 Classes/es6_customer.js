class Customer
{
    id = 0;
    name = " ";
    city = " ";
    constructor(name, id, city)
    {
        this.id = id;
        this.name = name;
        this.city = city
    }
    display()
    {
        document.write(this.name+" "+this.id+" "+this.city);
    }
}
let c = new Customer("rahul",22,"Hyderabad");
c.display();