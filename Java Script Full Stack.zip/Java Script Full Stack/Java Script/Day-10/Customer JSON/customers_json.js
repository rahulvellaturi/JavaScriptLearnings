let customers=[];

function add(n)
{
    for (let i=1; i<=n; i++)
    {
        let c_id = prompt("enter id:");
        let c_name = prompt("enter name:");
        let c_city = prompt("enter city:");
        let cus = {id: c_id, name: c_name, city: c_city};
        let jcus = JSON.stringify(cus);
        customers.push(jcus);
    }
}
function showAll()
{
    for (let cd of customers)
    {
        let c = JSON.parse(cd);
        document.write("ID: " + c.id + " <br>Name: " + c.name + " <br>City: " + c.city);
    }
}