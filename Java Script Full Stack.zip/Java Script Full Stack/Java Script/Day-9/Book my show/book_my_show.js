function bookTickets(eve)
{
    eve.preventDefault()
    let num1 = document.getElementById("num1").value;
    let price = document.getElementById("price").value;
    if (num1 >= 1 && num1 <= 6)
    {
        if (price != "")
        {
            let p = num1 *parseInt(price);
            document.getElementById("total").value = p;
        }
        else
        {
            alert("Field is not to be empty");
        }
    }
}