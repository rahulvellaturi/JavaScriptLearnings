function Employee(id,name,salary)
{
    this.id = id;
    this.name = name;
    this.salary = salary;
}

let emps = [];

function add(n)
{
    for (let i=1;i <=n; i++)
    {
        let id = prompt("enter id:");
        let name = prompt("enter name:");
        let salary = prompt("enter salary:");
        let e = new Employee(id, name, salary);
        emps.push(e);
    }
}

function showAll()
{
    for (let e of emps)
    {
        document.write("<br>id: "+e.id);
        document.write("<br>name: "+e.name);
        document.write("<br>salary: "+e.salary);
    }
}