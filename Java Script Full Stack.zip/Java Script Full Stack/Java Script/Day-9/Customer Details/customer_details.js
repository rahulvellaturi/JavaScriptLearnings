function Customer(id,name,city)
{
    this.id = id;
    this.name = name;
    this.city = city;
}

let cust = [];

function add(n)
{
    for (let i=1;i <=n; i++)
    {
        let id = prompt("enter id:");
        let name = prompt("enter name:");
        let city = prompt("enter city:");
        let c = new Customer(id, name, city);
        cust.push(c);
    }
}

function showAll()
{
    for (let c of cust)
    {
        document.write("<br>id: "+c.id);
        document.write("<br>name: "+c.name);
        document.write("<br>city: "+c.city);
    }
}