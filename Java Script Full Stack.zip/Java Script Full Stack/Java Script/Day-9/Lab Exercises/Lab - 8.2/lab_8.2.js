function productDetails()
{
    let c = document.getElementById("cat").value;
    let e_items = ["Television","Laptop","Phone"]
    let g_items = ["Soap","Powder"]
    let p = document.getElementById("product");
    if (c == "elect")
    {
        p.options.length = 0;
        for (let i=0; i<e_items.length; i++)
        {
            let opt = document.createElement("option");
            opt.text = e_items[i];
            opt.value = e_items[i]
            p.add(opt);
        }
    }
    else
    {
         p.options.length = 0;
         for (let i=0; i<g_items.length; i++)
        {
        let opt = document.createElement("option");
        opt.text = g_items[i];
        opt.value = g_items[i]
        p.add(opt);
        }
    }
}
function calculate(eve)
{
    eve.preventDefault();
    let c = document.getElementById("product").value;
    let r = document.getElementById("quant").value;
    if (c == "Television")
    {
        document.getElementById("total").value = (r*500);
    }
    if (c == "Laptop")
    {
        document.getElementById("total").value = (r*600);
    }
}