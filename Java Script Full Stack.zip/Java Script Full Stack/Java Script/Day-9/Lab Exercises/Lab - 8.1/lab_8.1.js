function compute(eve)
{
    eve.preventDefault()
    let la = document.getElementById("loanamnt").value;
    let loanamnt = 0;
    if (la < 1500000)
    {
        loanamnt = parseInt(la);
    }
    else
    {
        alert("Enter the amount less than 1500000");
    }
    let p = document.getElementById("percent").value;
    let proi = 0;
    if (p >= 1)
    {
        proi = p;
    }
    else
    {
        alert("number should be greater than zero");
    }
    let rpay = document.getElementById("repay").value;
    let totalinterest = (loanamnt * proi * rpay)/100;
    document.getElementById('totalinterest').value = totalinterest;
    document.getElementById('total').value = totalinterest+loanamnt;
    let monthly = (loanamnt + totalinterest)/12;
    document.getElementById('monthly').value = monthly;
}
