function showCourses()
{
    let t = document.getElementById('tech').value;
    let f_courses = ["HTML","Javascript"]
    let b_courses = ["Java","DotNet"]
    let c = document.getElementById("course");
    if (t == "fet")
    {
        c.options.length = 0;
        for ( let i=0; i<f_courses.length; i++)
        {
        let opt = document.createElement("option");
        opt.text = f_courses[i];
        opt.value = f_courses[i]
        c.add(opt);
        }
    }
    else
    {
        c.options.length = 0;
       for ( let i=0; i<b_courses.length; i++)
        {
        let opt = document.createElement("option");
        opt.text = b_courses[i];
        opt.value = b_courses[i]
        c.add(opt);
        }
    }
}
function calculate()
{
    let c = document.getElementById("course").value;
    let n = document.getElementById("en").value;
    if (c == "HTML")
    {
        document.getElementById("total").value = n*20000;
    }
    if (c == "Javascript")
    {
        document.getElementById("total").value = n*30000;
    }
}