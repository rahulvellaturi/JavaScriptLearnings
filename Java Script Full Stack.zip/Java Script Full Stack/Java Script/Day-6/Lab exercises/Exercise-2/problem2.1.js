function print1to100()
{
    for(let i=1; i<100; i++)
    {
    if (i%10 == 0)
    {
        document.write("<br>")
    }
    document.write(i+ " ")
}
}
print1to100();