function calculateCompoundinterest()
{
    let p=1000;
    let r=10;
    let n = 1;
    let ci = (p * Math.pow((1+r/100), n)) -p;
    document.write("-----------------------------------------------<br>")
    document.write("********Compound Interest********<br>");
    document.write("-----------------------------------------------<br>")
    document.write("Principal &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; - &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"+p+"rs<br>");
    document.write("Rate Of Interest &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; -   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"+r+"%<br>");
    document.write("Period &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; - &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"+n+"Yr<br>");
    document.write("Compound Interest &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; - &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"+ci+"<br>");
}
calculateCompoundinterest();