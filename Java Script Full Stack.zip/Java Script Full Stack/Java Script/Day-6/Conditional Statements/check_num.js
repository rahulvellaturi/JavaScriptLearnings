// function checkNum(n)//if condition
// {
//     if (n >=0)
//     {
//         document.write("Positive");
//     }
//     else
//     {
//         document.write("negative");
//     }
// }
// checkNum(9);
// function checkEvenOdd(n)//if else condition
// {
//     if (n%2 == 0)
//     {
//         document.write("even");
//     }
//     else
//     {
//         document.write("odd");
//     }
// }
// checkEvenOdd(7)
// function checkMultipleOfTen(n)//if else condition
// {
//     if (n%10==0)
//     {
//         document.write("Multiple of ten");
//     }
//     else
//     {
//         document.write("Not multiple of ten");
//     }
// }
// checkMultipleOfTen(100)
// function findGrade(marks)//if else elseif condition
// {
//     if (marks>=90 && marks<=100)
//     {
//         document.write("Grade A");
//     }
//     else if(marks<90 && marks>=80)
//     {
//         document.write("Grade B");
//     }
//     else if(marks<80 && marks>=60)
//     {
//         document.write("Grade C");
//     }
//     else if(marks<60)
//     {
//         document.write("Fail");
//     }
//     else
//     {
//         document.write("Absent");
//     }
// }
// findGrade(100)
// function display()
// {
//     alert("hai");
// }
// display();
function fizzbuzz(num)
{
    if (num%3==0 && num%5==0)
    {
        document.write("Fizz");
    }
    else if(num%5==0)
    {
        document.write("Buzz");
    }
    else if(num%3==0)
    {
        document.write("Fizz Buzz");
    }
    else
    {
        document.write("print number");
    }
}
fizzbuzz(2343636455)