// function print1to10()
// {
//     let i=1;
//     while (i<=10)
//     {
//         document.write("i: " + i + "<br>");
//         i++;
//     }
// }
// print1to10();
// function demoFor1to10()
// {
//     for(i=1;i<=10;i++)
//     {
//         document.write("i: "+i+"<br>");
//     }
// }
// demoFor1to10();
// function doWhileDemo()
// {
//     let i=1;
//     do
//     {
//         document.write("i:" +i+"<br>")
//         i++;
//     }while (i<=10);
// }
// doWhileDemo();
// function display()
// {
//     let i=1;
//     if (i-- && ++i)
//     {
//     document.write(i)
// }
// document.write(i);
// }  
// display();
//program to print even numbers
// function display()
// {
//     for(let i=1; i<=10; i++)
//     if (i%2 == 0)
//     {
//         document.write(i+ "<br>")
//     }
// }
// display();
//program to print even numbers
// function display()
// {
//     for(let i=3; i<=10; i++)
//     if (i%2 == 1)
//     {
//         document.write(i+ "<br>")
//     }
// }
// display();
// function printSum()
// {
//     let sum = 0
//     for(let i=1;i<=10;i++)
//     {
//         sum=sum+i;
//     }
// document.write("result: "+sum)
// }
// printSum();