function mathDemo1()
{
    document.write("math abs: " + Math.abs(-3)+"<br>");
    document.write("ceil: "+ Math.ceil(3.2)+"<br>");
    document.write("floor: "+ Math.floor(3.9)+"<br>");
    document.write("round: "+ Math.round(3.2)+"<br>");
    document.write("round: "+ Math.round(3.5)+"<br>");
    document.write("min: "+ Math.min(4, 2) + "<br>");
    document.write("max: "+ Math.max(4 , 2) + "<br>");
    document.write("sqrt: "+ Math.sqrt(4) + "<br>");
    document.write("cbrt: "+ Math.cbrt(9) + "<br>");
    document.write("random: "+ Math.random() + "<br>");
}
mathDemo1();