function dosum()
{
    let a = document.getElementById('text').value;
    let b = document.getElementById('text1').value;
    alert (parseInt(a) + parseInt(b))
    let pr = window.open("","","width = 400; height = 400");
    pr.document.write(a + "<br>");
    pr.document.write(b + "<br>");
}
function dosub()
{
    let a = document.getElementById('text').value;
    let b = document.getElementById('text1').value;
    alert (parseInt(a) - parseInt(b))
    let pr = window.open("","","width = 400; height = 400");
    pr.document.write(a + "<br>");
    pr.document.write(b + "<br>");
}