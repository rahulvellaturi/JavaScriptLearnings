// function arrayDemo1()
// {
//     let skills = ['Java','Angular','Pega','React'];
//     for (let a = 0; a < skills.length; a++)
//     {
//         document.write(skills[a] + "<br>")
//     }
// }
// arrayDemo1();
function arrayDemo2()
{
    let prices = [101,102,103,104];
    for (let n of prices)//for each loop.
    {
        document.write(n + "<br>")
    }
}
arrayDemo2();