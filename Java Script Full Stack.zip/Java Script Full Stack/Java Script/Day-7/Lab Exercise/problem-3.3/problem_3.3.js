function problem3_3()
{
    let company = "University at Capgemini";
    document.write("String is:" + company.toString() + "<br>");
    document.write("Result of str.match('Capgemini'): " + company.substring(25,14) + "<br>");
    document.write("Result of str.substr: " + company.substr(3,6) + "<br>");
    let text = "hello javascripters!"
    document.write("" + text.toLowerCase() + "<br>");
    document.write("" + text.toUpperCase() + "<br>");
}
problem3_3();