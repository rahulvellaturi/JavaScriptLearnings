function problem3_2()
{
    let company = "Capgemini";
    document.write("The actual string is:" + company.toString() + "<br>");
    document.write("The character to be searched for is: " + company.charAt(2) + "<br>");
    document.write("The character is found at the index: " + company.indexOf('p') + "<br>");
}
problem3_2();