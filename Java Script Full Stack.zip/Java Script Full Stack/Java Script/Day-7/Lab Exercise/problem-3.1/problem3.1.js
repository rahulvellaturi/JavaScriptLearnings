function dateProblem3_1()
{
    let d = new Date();
    document.write(d + "<br>");
let hrs = d.getHours();
if (hrs>=12 & hrs<= 17)
    {
        document.write("Good Afternoon");
    }
    else if(hrs < 12)
    {
        document.write("Good Morning");
    }
    else if(hrs > 17)
    {
        document.write("Good Evening");
    }
    else
    {
        document.write("Good Night");
    }
}
dateProblem3_1();
// function dateDemo()
// {
//     let d = new Date();
//     let hrs = d.getHours();
//     let m = d.getMinutes();
//     let s = d.getSeconds();
//     document.getElementById("timer").innerText = hrs + ":" + m +":" + s
// }
// setInterval(dateDemo, 1000)