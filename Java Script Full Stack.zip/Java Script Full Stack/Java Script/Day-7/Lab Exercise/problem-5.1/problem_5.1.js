function newWindow()
{
    let h1 = document.getElementById('h').value;
    let w1 = document.getElementById('w').value;
    let l1 = document.getElementById('l').value;
    let t1 = document.getElementById('t').value;
    let pr = window.open("","","Left = " +l1+ ",Top=" +t1+ ",Height=" +h1+ ",Width=" +w1+ " ");
    pr.document.write("The new window is open");
}