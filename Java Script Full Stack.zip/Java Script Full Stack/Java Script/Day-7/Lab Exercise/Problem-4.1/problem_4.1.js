function ListOfEmployees()
{
    document.write("List of Employees"+"<br>");
    document.write("-----------------------"+"<br>");
    let loe = ["Tove","Hege","Stale","Kai Jim","Borge","Undefined"];
    for (let a = 0; a < loe.length; a++)
    {
        document.write((a+1) + ". " + loe[a] + "<br>");
    }
}
ListOfEmployees();