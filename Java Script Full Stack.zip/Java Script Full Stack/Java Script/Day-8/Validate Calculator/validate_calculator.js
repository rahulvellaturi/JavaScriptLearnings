function validate()
{
    let x = document.getElementById('num1').value;
    let y = document.getElementById('num2').value;
    if (x == '' && y =='')
    {
        alert("Field should not be empty");
    }
    else
    {
        let a = parseInt(x)
        let b = parseInt(y)
        let pr = window.open("","","width=400","height=400");
        pr.document.write("number 1:  "+a+"<br>");
        pr.document.write("number 2:  "+b+"<br>");
        pr.document.write("result:  "+(a+b)+"<br>");
    }
}   