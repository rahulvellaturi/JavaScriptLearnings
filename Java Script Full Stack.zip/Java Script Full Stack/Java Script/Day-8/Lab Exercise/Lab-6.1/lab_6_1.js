function calculate_price()
{
    let a = document.getElementById('qty1').value;
    let b = document.getElementById('qty2').value;
    let c = document.getElementById('qty3').value;
    let d = document.getElementById('qty4').value;
    if (a == '' && b =='' && c == '' && d == '')
    {
        alert("no item selected");
    }
    else
    {
        let pr = window.open("","","width = 400, height = 400")
        pr.document.write("<h1 align = center>Invoice</h1>")

        pr.document.write("<table border=1><tr><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL</th></tr>");
        if(a!='')
        {
            let BD = parseInt(a)*20;
            pr.document.write("<tr><td>BarbieDoll</td><td>"+a+"</td><td>20</td><td>"+BD+"</td></tr>");
        }
        if(b!='')
        {
            let CL = parseInt(b)*30;
            pr.document.write("<tr><td>Calculator</td><td>"+b+"</td><td>30</td><td>"+CL+"</td></tr>");
        }
        if(c!='')
        {
            let MP = parseInt(c)*40;
            pr.document.write("<tr><td>MobilePhone</td><td>"+c+"</td><td>40</td><td>"+MP+"</td></tr>");
        }
        if(d!='')
        {
            let LD = parseInt(d)*50;
            pr.document.write("<tr><td>LGDVD</td><td>"+d+"</td><td>50</td><td>"+LD+"</td></tr>");
        }
        pr.document.write("</table>");
    }
}