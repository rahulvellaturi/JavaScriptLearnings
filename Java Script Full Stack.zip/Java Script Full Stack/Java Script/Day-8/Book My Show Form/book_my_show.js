function priceOftickets()
{
    let amount = 150;
    let x = document.getElementById('num1').value;
    if (x == '')
    {
        alert("Please select the tickets")
    }
    else
    {
        let pr = window.open("","","width=400","height=400");
        pr.document.write("number of tickets:  "+x+"<br>");
        pr.document.write("payment:  "+ (x * amount) +"<br>");
    }
}   