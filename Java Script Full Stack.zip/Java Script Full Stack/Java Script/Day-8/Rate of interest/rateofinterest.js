function calculateEmI(eve)
{
    eve.preventDefault()
    let la = document.getElementById('loanamt').value
    let loanAmount = 0;
    if (la >= 100000 && la <= 500000)
    {
        loanAmount = parseInt(la);
    }
    else
    {
        alert("only numbers");
    }
    let r = document.getElementById('roi').value;
    let roi = 0;
    if (r >= 1)
    {
        roi = parseInt(r);
    }
    else
    {
        alert("number should be greater than zero");
    }
    let p= document.getElementById('tenure').value;
    let interestAmount = (loanAmount * roi * p)/100;
    document.getElementById('IAmnt').value = interestAmount;
    let monthlyEmI = (loanAmount + interestAmount)/12;
    document.getElementById('MEMI').value = monthlyEmI;
}